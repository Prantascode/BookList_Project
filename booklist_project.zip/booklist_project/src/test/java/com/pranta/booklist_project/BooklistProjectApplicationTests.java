package com.pranta.booklist_project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BooklistProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
